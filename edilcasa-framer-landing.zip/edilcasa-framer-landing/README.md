# EDILCASA — Framer-style Landing (Next.js)

## Avvio locale
```bash
npm i
npm run dev
```
Apri http://localhost:3000

## Build
```bash
npm run build
npm run start
```

## Dove cambiare contenuti
Tutti i testi/dati stanno in: `src/lib/content.ts`

## Note
- Form contatto è demo (frontend only). Collega un endpoint / CRM quando vai live.
- Immagini: placeholder con gradient. Inserisci foto reali nei componenti (e usa next/image).
